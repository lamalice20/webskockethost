from basicCGIserver import startCGIserver
from basicserverhttp import start_server_http
from client_socket import connect, chat
from server_socket import bind_server, chat